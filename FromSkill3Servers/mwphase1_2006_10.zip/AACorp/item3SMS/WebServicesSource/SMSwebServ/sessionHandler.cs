using System;
using System.Data;
using System.Data.SqlClient;
namespace skill3.SMSwebServ
{
	/// <summary>
	/// Summary description for sessionHandler.
	/// </summary>
	public class sessionHandler
	{
		#region declares
		public string connectionString;
		public SqlConnection connection1;
		public bool useSMSresponseForErrorReporting=false; 
		public string outgoingNowSMSaddress,defaultSenderNumber,defaultSMSresponse;
		public int outgoingNowSMStcPport,retainMessagesForPolling;
		public dtstSMS dtst1;
		public bool pushMode;
		public bool pollMode;
		private long _lastReceivedInternalID=0; //used for other applications to poll based on their last known internalID
		#endregion
		public long  lastReceivedInternalID
		{
			get
			{
				//if (this._lastReceivedInternalID==0)
				return this._lastReceivedInternalID;	
			}
			set
			{
				if (value>this._lastReceivedInternalID)
					this._lastReceivedInternalID=value;
			}
		}
		public sessionHandler() //initializer
		{
			System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
			this.connection1 = new System.Data.SqlClient.SqlConnection();
			this.useSMSresponseForErrorReporting = ((bool)(configurationAppSettings.GetValue("useSMSresponseForErrorReporting", typeof(bool))));
			this.defaultSMSresponse = ((string)(configurationAppSettings.GetValue("defaultSMSresponse", typeof(string))));
			this.outgoingNowSMSaddress = ((string)(configurationAppSettings.GetValue("outgoingNowSMSaddress", typeof(string))));
			this.defaultSenderNumber = ((string)(configurationAppSettings.GetValue("defaultSenderNumber", typeof(string))));
			this.outgoingNowSMStcPport = ((int)(configurationAppSettings.GetValue("outgoingNowSMStcPport", typeof(int))));
			this.retainMessagesForPolling = ((int)(configurationAppSettings.GetValue("retainMessagesForPolling", typeof(int))));
			this.connection1.ConnectionString = ((string)(configurationAppSettings.GetValue("ConnectionString", typeof(string))));
			string pushORpoll;
			pushORpoll=this.connection1.ConnectionString = ((string)(configurationAppSettings.GetValue("pushORpoll", typeof(string))));
			pushORpoll=pushORpoll.ToLower();
			if (pushORpoll=="push")
				pushMode=true;
			if (pushORpoll=="poll")
				pollMode=true;
			this.connection1.Open();
			this.dtst1=new dtstSMS();
		}
		public void holdSMS(long internalId,string sender,string receiver,string text,string connectionId)
		{	if (this.dtst1.incoming.Rows.Count>=this.retainMessagesForPolling)
				return;
			dtstSMS.incomingRow sms1;
			sms1=this.dtst1.incoming.NewincomingRow();
			sms1.internalID=internalId;
			sms1.internalTime=DateTime.Now;
			sms1.processed=false;
			sms1.sender=sender;
			sms1.receiver=receiver;
			sms1.smsContent=text;
			sms1.connectionId=connectionId;
			this.dtst1.incoming.AddincomingRow(sms1);
			sms1.AcceptChanges();
		}
	}
}
