using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace skill3.SMSwebServ
{
	/// <summary>
	/// Summary description for smsQueue.
	/// </summary>
	public class smsQueue : System.Web.Services.WebService
	{
		public smsQueue()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}
		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion
		[WebMethod] public int queueSize()
		{
			sessionHandler appData;
			appData=(sessionHandler)Application["appData"];
			return appData.dtst1.incoming.Rows.Count;
		}
		[WebMethod] public dtstSMS pollSMS()
		{
			sessionHandler appData;
			appData=(sessionHandler)Application["appData"];
			dtstSMS dtstReturn=appData.dtst1;
			appData.dtst1=new dtstSMS();
			return dtstReturn;
		}
	}
}
