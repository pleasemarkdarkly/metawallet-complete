using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace skill3.SMSwebServ
{
	/// <summary>
	/// receives an incoming sms from nowSMS via http get
	/// nowsms mut be configured to send the request here
	/// all implementation is on teh load event
	/// output is text wich can be ignored or sent back as an aknowledgement SMS
	/// 
	/// </summary>
	public class incoming : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			//all instances of this service share application data trough this object, creates in the appstart evet
			sessionHandler appData=null;
			try
			{
				appData=(sessionHandler)Application["appData"];
				//local declares
				string sendr,receiver,smsConnection,smsContent;
				long internalId;
				bool connectionCreated=false;
				//------------------------------------------------------------
				//sms comes over http GET querystring
				//nowsms should be configured like this on 2 way settings
				//http://localhost:88/SMSwebServ/incoming.aspx?sender=@@SENDER@@&smsConnection=NowsmsBolViva1&receiver=@@RECIP@@&smsContent=@@FULLSMS@@
				//there are many more options for binary, no timplemented here
				//------------------------------------------------------------
				sendr        =this.Request.QueryString["sender"];
				receiver     =this.Request.QueryString["receiver"];
				smsConnection=this.Request.QueryString["smsConnection"];
				smsContent   =this.Request.QueryString["smsContent"];
				this.cmdReceive.Parameters["@sender"].Value=sendr;
				this.cmdReceive.Parameters["@receiver"].Value=receiver;
				this.cmdReceive.Parameters["@conId"].Value=smsConnection;
				this.cmdReceive.Parameters["@sms"].Value=smsContent;
				if (appData.connection1.State==ConnectionState.Open)
					this.cmdReceive.Connection=appData.connection1;
				else 
				{
					this.cmdReceive.Connection=new SqlConnection(appData.connectionString);
					this.cmdReceive.Connection.Open();
					connectionCreated=true;
				}
				internalId=(long)this.cmdReceive.ExecuteScalar();
				appData.lastReceivedInternalID=internalId;
				//if polling will be used, queue the sms in memory;
				if (appData.retainMessagesForPolling>0 & appData.pollMode)
					appData.holdSMS(internalId,sendr,receiver,smsContent,smsConnection);
				if (appData.pushMode)
					try
					{	string processed;
						pushApp.smsAppSample push1=new pushApp.smsAppSample();
						processed=push1.processSMS(internalId,sendr,receiver,smsContent,smsConnection);
						if (processed=="!")
						{
							this.cmdProcessed.Parameters[0].Value=internalId;
							this.cmdProcessed.ExecuteNonQuery();
						}
						else if (processed!=string.Empty)
						{
							smsSender send1 =new smsSender();
							send1.sendSMS(receiver ,sendr,processed);
							this.cmdProcessed.Parameters[0].Value=internalId;
							this.cmdProcessed.ExecuteNonQuery();
						}
					}
					catch
					{
					}
				//if the connection was created locally, then close it
				if (connectionCreated) this.cmdReceive.Connection.Close();
				this.litResponse.Text=appData.defaultSMSresponse.Replace("@@msgId@@",internalId.ToString());
			}
			catch (Exception exc)
			{
				if (appData!=null)
					if (appData.useSMSresponseForErrorReporting)
						this.litResponse.Text=exc.Message;
			}
		}
		protected System.Data.SqlClient.SqlCommand cmdReceive;
		protected System.Data.SqlClient.SqlCommand cmdProcessed;
		#region Web Form Designer generated code
		protected System.Web.UI.WebControls.Literal litResponse;
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdReceive = new System.Data.SqlClient.SqlCommand();
			this.cmdProcessed = new System.Data.SqlClient.SqlCommand();
			// 
			// cmdReceive
			// 
			this.cmdReceive.CommandText = "dbo.[SPreceived]";
			this.cmdReceive.CommandType = System.Data.CommandType.StoredProcedure;
			this.cmdReceive.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.cmdReceive.Parameters.Add(new System.Data.SqlClient.SqlParameter("@sender", System.Data.SqlDbType.VarChar, 15));
			this.cmdReceive.Parameters.Add(new System.Data.SqlClient.SqlParameter("@receiver", System.Data.SqlDbType.VarChar, 15));
			this.cmdReceive.Parameters.Add(new System.Data.SqlClient.SqlParameter("@conId", System.Data.SqlDbType.VarChar, 15));
			this.cmdReceive.Parameters.Add(new System.Data.SqlClient.SqlParameter("@sms", System.Data.SqlDbType.VarChar, 170));
			// 
			// cmdProcessed
			// 
			this.cmdProcessed.CommandText = "dbo.[spProcessed]";
			this.cmdProcessed.CommandType = System.Data.CommandType.StoredProcedure;
			this.cmdProcessed.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.cmdProcessed.Parameters.Add(new System.Data.SqlClient.SqlParameter("@id", System.Data.SqlDbType.BigInt, 8));
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
