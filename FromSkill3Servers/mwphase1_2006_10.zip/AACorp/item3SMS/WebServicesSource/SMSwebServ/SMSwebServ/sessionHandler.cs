using System;
using System.Data;
using System.Data.SqlClient;
namespace skill3.SMSwebServ
{
	/// <summary>
	/// Summary description for sessionHandler.
	/// </summary>
	public class sessionHandler
	{
		public string connectionString;
		public SqlConnection connection1;
		public bool useSMSresponseForErrorReporting=false; 
		public string outgoingNowSMSaddress,defaultSenderNumber,defaultSMSresponse;
		public int outgoingNowSMStcPport,retainMessagesForPolling;
		public System.Collections.Queue heldSMS;
		private long _lastReceivedInternalID=0; //used for other applications to poll based on their last known internalID
		public long  lastReceivedInternalID
		{
			get
			{
				//if (this._lastReceivedInternalID==0)
				return this._lastReceivedInternalID;	
			}
			set
			{
				if (value>this._lastReceivedInternalID)
					this._lastReceivedInternalID=value;
			}
		}
		public sessionHandler() //initializer
		{
			System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
			this.connection1 = new System.Data.SqlClient.SqlConnection();
			this.useSMSresponseForErrorReporting = ((bool)(configurationAppSettings.GetValue("useSMSresponseForErrorReporting", typeof(bool))));
			this.defaultSMSresponse = ((string)(configurationAppSettings.GetValue("defaultSMSresponse", typeof(string))));
			this.outgoingNowSMSaddress = ((string)(configurationAppSettings.GetValue("outgoingNowSMSaddress", typeof(string))));
			this.defaultSenderNumber = ((string)(configurationAppSettings.GetValue("defaultSenderNumber", typeof(string))));
			this.outgoingNowSMStcPport = ((int)(configurationAppSettings.GetValue("outgoingNowSMStcPport", typeof(int))));
			this.retainMessagesForPolling = ((int)(configurationAppSettings.GetValue("retainMessagesForPolling", typeof(int))));
			this.connection1.ConnectionString = ((string)(configurationAppSettings.GetValue("ConnectionString", typeof(string))));
			this.connection1.Open();
			this.heldSMS=new System.Collections.Queue();
		}
		public void holdSMS(long internalId,string sender,string receiver,string text,string connectionId)
		{
			this.heldSMS.Enqueue(new sms(internalId,sender,receiver,text,connectionId));
			if (heldSMS.Count>this.retainMessagesForPolling)
				this.heldSMS.Dequeue();
			//if the queue gets bigger than expected, messages are dropped from memory, but they remain in the database
		}
	}
	public struct sms
	{
		long internalId;
		DateTime internalTime;
		string sender,receiver,text,connectionId;
		public sms(long internalId,string sender,string receiver,string text,string connectionId)
		{
			this.internalId=internalId;
			this.sender=sender;
			this.receiver=receiver;
			this.text=text;
			this.connectionId=connectionId;
			this.internalTime=DateTime.Now;
		}
	}
}
