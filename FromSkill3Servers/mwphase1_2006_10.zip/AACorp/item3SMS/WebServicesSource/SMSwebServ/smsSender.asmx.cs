using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;
using skill3.SMSwebServ;
using System.Text;
namespace skill3.SMSwebServ
{
	/// <summary>
	/// this simple web service translates an XML request into nowsms 
	/// weeb send request (which is a non-xml web service)
	/// it also feeds the log database
	/// </summary>
	public class smsSender : System.Web.Services.WebService
	{
		public smsSender()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		private System.Data.SqlClient.SqlCommand cmdSent;
		private System.Data.SqlClient.SqlCommand cmdLogResponse;

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmdSent = new System.Data.SqlClient.SqlCommand();
			this.cmdLogResponse = new System.Data.SqlClient.SqlCommand();
			// 
			// cmdSent
			// 
			this.cmdSent.CommandText = "dbo.[SPsent]";
			this.cmdSent.CommandType = System.Data.CommandType.StoredProcedure;
			this.cmdSent.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.cmdSent.Parameters.Add(new System.Data.SqlClient.SqlParameter("@sender", System.Data.SqlDbType.VarChar, 15));
			this.cmdSent.Parameters.Add(new System.Data.SqlClient.SqlParameter("@receiver", System.Data.SqlDbType.VarChar, 15));
			this.cmdSent.Parameters.Add(new System.Data.SqlClient.SqlParameter("@server", System.Data.SqlDbType.VarChar, 50));
			this.cmdSent.Parameters.Add(new System.Data.SqlClient.SqlParameter("@sms", System.Data.SqlDbType.VarChar, 170));
			// 
			// cmdLogResponse
			// 
			this.cmdLogResponse.CommandText = "dbo.[SPsentResponse]";
			this.cmdLogResponse.CommandType = System.Data.CommandType.StoredProcedure;
			this.cmdLogResponse.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.cmdLogResponse.Parameters.Add(new System.Data.SqlClient.SqlParameter("@response", System.Data.SqlDbType.VarChar, 255));
			this.cmdLogResponse.Parameters.Add(new System.Data.SqlClient.SqlParameter("@internalId", System.Data.SqlDbType.BigInt, 8));

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion
		//sends an sms message over Now SMS, logs it to the database and returns teh internal sequence number
		//if it fails, it returns a negatie number
		// -1 error loging to the database before sending
		// -2 error sending
		// -3 error logging the sent response to the database
		[WebMethod] public long sendSMS(string sender,string receiver,string text)
		{
			long internalId=-1;
			sessionHandler appData;
			try
			{
				appData=(sessionHandler)Application["appData"];
				bool connectionCreated=false;
				string url="http://@@serv@@:@@port@@/Send%20Text%20Message.htm?PhoneNumber=@@rece@@" +
					"&Text=@@smsT@@&InfoCharCounter=&PID=&DCS=&Submit=Submit&sender=@@send@@";
				if (sender==string.Empty)
					sender=appData.defaultSenderNumber;
				url=url.Replace("@@serv@@",appData.outgoingNowSMSaddress);
				url=url.Replace("@@port@@",appData.outgoingNowSMStcPport.ToString());
				url=url.Replace("@@rece@@",receiver);
				url=url.Replace("@@send@@",sender);
				url=url.Replace("@@smsT@@",text);
				this.cmdSent.Parameters["@sender"].Value=sender;
				this.cmdSent.Parameters["@receiver"].Value=receiver;
				this.cmdSent.Parameters["@server"].Value=appData.outgoingNowSMSaddress + ":" + appData.outgoingNowSMStcPport.ToString();
				this.cmdSent.Parameters["@sms"].Value=text;
				if (appData.connection1.State==ConnectionState.Open)
					this.cmdSent.Connection=appData.connection1;
				else 
				{
					this.cmdSent.Connection=new SqlConnection(appData.connectionString);
					this.cmdSent.Connection.Open();
					connectionCreated=true;
				}
				internalId=(long)this.cmdSent.ExecuteScalar();
				//hasta aqui se logeo lo que se va a intentar enviar
				//proceder al env�o
				System.Net.WebClient webC=new System.Net.WebClient();
				byte[] response;
				char[] responseC;
				string responseS=string.Empty;
				try
				{
					response=webC.DownloadData(url);
				}
				catch (Exception EX)
				{
					return -2;
				}
				ASCIIEncoding AE = new ASCIIEncoding();
				responseC=AE.GetChars(response);
				foreach (char c1 in responseC)
				{
					responseS += c1;
				}
				//the response is an html doccument. strip it of html headers in order to save the usable text
				if (responseS.StartsWith("<HTML>") & responseS.Length>161 )
				{
					responseS=responseS.Substring(161);
					if (responseS.IndexOf("")>-1)
					{
					
					}
				}
				if (responseS.Length>255) responseS=responseS.Substring(0,255);
				this.cmdLogResponse.Connection=this.cmdSent.Connection;
				this.cmdLogResponse.Parameters["@response"].Value=responseS;
				this.cmdLogResponse.Parameters["@internalId"].Value=internalId;
				try
				{
					this.cmdLogResponse.ExecuteNonQuery();
				}
				catch
				{
					return -3;
				}
				if (connectionCreated & this.cmdSent.Connection.State==ConnectionState.Open)
					this.cmdSent.Connection.Close();
				return internalId;
			}
			catch (Exception EX)
			{
				return -1;
			}
		}
	}
}
/*		string dfText="http://localhost:8800/Send%20Text%20Message.htm?PhoneNumber=@@0@@" +
			"&Text=@@1@@&InfoCharCounter=&PID=&DCS=&Submit=Submit";*/