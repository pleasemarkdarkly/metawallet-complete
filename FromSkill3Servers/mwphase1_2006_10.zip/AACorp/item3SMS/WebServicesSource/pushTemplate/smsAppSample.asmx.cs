using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace pushTemplate
{
	/// <summary>
	/// Summary description for smsAppSample.
	/// </summary>
	public class smsAppSample : System.Web.Services.WebService
	{
		public smsAppSample()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion
		[WebMethod] public string processSMS(long internalId,string sender,string receiver,string text,string connectionId)
		{
			//return values:
			//an empty string=do not send a response, do not mark the message as processed
			//"!"=mark the message processed, do not send any response
			//any other string wil be sent as a rsponse, if it's longer that one SMS, it will be split
			//implement you application here, good luck
			string s="!";
			return s;
		}
	}
}
