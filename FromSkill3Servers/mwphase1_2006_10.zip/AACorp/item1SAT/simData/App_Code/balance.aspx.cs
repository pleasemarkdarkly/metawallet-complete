using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace simData
{
	public partial class balance : System.Web.UI.Page
	{
		protected System.Data.SqlClient.SqlConnection sqlConnection1;
		protected System.Data.SqlClient.SqlCommand sqlCLogReq;
		protected void Page_Load(object sender, System.EventArgs e)
		{
			try
			{
				this.sqlCLogReq.Parameters["@dat"].Value= this.Request.Url.ToString();
				if (this.sqlConnection1.State!=System.Data.ConnectionState.Open) this.sqlConnection1.Open();
				this.sqlCLogReq.ExecuteNonQuery();
			}
			catch(Exception Ex)
			{
				Ex.ToString();
			}
			try
			{
				string number;
				ntws.balance1Response response;
				if (this.Request.QueryString["n"]!=null)
					if (this.Request.QueryString["n"].Length>0)
					{
						number=this.Request.QueryString["n"];
						if (number.Length==8) number = "591" + number;
						ntws.Service1 ws = new ntws.Service1();
						response=ws.wsbalanceEnquiry1(number,string.Empty);
						//this.litText.Text=response.balance.ToString("0.00");
					}
			}
			catch (Exception ex)
			{
				//this.litText.Text=ex.Message;
			}
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlCLogReq = new System.Data.SqlClient.SqlCommand();
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = "workstation id=CGWORKSTATION;packet size=4096;user id=smsIOusr;data source=\"(loca" +
				"l)\";persist security info=True;initial catalog=smsIO;password=fVhAUcSq7tEm";
			// 
			// sqlCLogReq
			// 
			this.sqlCLogReq.CommandText = "dbo.[spLogReq]";
			this.sqlCLogReq.CommandType = System.Data.CommandType.StoredProcedure;
			this.sqlCLogReq.Connection = this.sqlConnection1;
			this.sqlCLogReq.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCLogReq.Parameters.Add(new System.Data.SqlClient.SqlParameter("@dat", System.Data.SqlDbType.VarChar, 255));

		}
		#endregion
	}
}
