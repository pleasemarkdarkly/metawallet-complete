
using System;
using System.Web;
namespace simData
{
	public class SATMLhandler : IHttpHandler
	{
		HttpApplication aspxhand;
		public SATMLhandler()
		{
			aspxhand=new HttpApplication();
		}
		public void ProcessRequest(HttpContext context)
		{
			//implement the handler here
		}
		public bool IsReusable
		{
			get { return true; }
		}
	}
}
