using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WebServiceBG
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmTestWebService : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtSend;
		private System.Windows.Forms.TextBox txtReceive;
		private System.Windows.Forms.Button cmdSubmit;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmTestWebService()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtSend = new System.Windows.Forms.TextBox();
			this.txtReceive = new System.Windows.Forms.TextBox();
			this.cmdSubmit = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtSend
			// 
			this.txtSend.Location = new System.Drawing.Point(16, 16);
			this.txtSend.Multiline = true;
			this.txtSend.Name = "txtSend";
			this.txtSend.Size = new System.Drawing.Size(320, 96);
			this.txtSend.TabIndex = 0;
			this.txtSend.Text = "";
			// 
			// txtReceive
			// 
			this.txtReceive.Location = new System.Drawing.Point(16, 136);
			this.txtReceive.Multiline = true;
			this.txtReceive.Name = "txtReceive";
			this.txtReceive.Size = new System.Drawing.Size(320, 96);
			this.txtReceive.TabIndex = 1;
			this.txtReceive.Text = "";
			// 
			// cmdSubmit
			// 
			this.cmdSubmit.Location = new System.Drawing.Point(260, 252);
			this.cmdSubmit.Name = "cmdSubmit";
			this.cmdSubmit.TabIndex = 2;
			this.cmdSubmit.Text = "Submit";
			this.cmdSubmit.Click += new System.EventHandler(this.cmdSubmit_Click);
			// 
			// frmTestWebService
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(612, 362);
			this.Controls.Add(this.cmdSubmit);
			this.Controls.Add(this.txtReceive);
			this.Controls.Add(this.txtSend);
			this.Name = "frmTestWebService";
			this.Text = "Test Webservice";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmTestWebService());
		}

		private void cmdSubmit_Click(object sender, System.EventArgs e)
		{
			
			System.Net.ServicePointManager.CertificatePolicy = new MyPolicy();

			
			string bankresponse;
			wsScpCelu.WsScpCelu wsInquiry = new wsScpCelu.WsScpCelu();
					
			try	
			{
				
				bankresponse=wsInquiry.Servicios_Celular(10,777,72168674,"13/sep/2006",108493, 4970,"E","10" ,1);
				this.txtReceive.Text=bankresponse;}
			catch (System.Net.WebException ex)
			{//this.txtReceive.Text=ex.Message.ToString();
			this.txtReceive.Text="Error";}

		}
	}
}
