using System;
using System.Net;
using System.Security.Cryptography.X509Certificates;

namespace WebServiceBG
{
	/// <summary>
	/// Summary description for MyPolicy.
	/// </summary>
	public class MyPolicy: ICertificatePolicy 
	{
		public bool CheckValidationResult(ServicePoint srvPoint, X509Certificate certificate, WebRequest request, int certificateProblem) 
		{
			// Check for policy common name mismatch. 
			//if (certificateProblem == 0 || certificateProblem == 0x800c010f)
				return true;
			//else
				//return false; 
		}
	}
}

