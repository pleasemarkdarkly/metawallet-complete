using System;

// Aditional namespaces
using System.Net.Sockets;
using System.Net;
using System.Text;


namespace ntws
{
	/// <summary>
	/// Summary description for SpaConnector.
	/// </summary>
	public class SpaConnector
	{
		
		private string hostIP="";
		private int portNumber=0;
		private string userName="";
		private string passwordSPA="";


		
		public SpaConnector(string hostIPNew,int portNumberNew,string userNameNew,string passwordSPANew)
		{
			
			hostIP=hostIPNew;
			portNumber=portNumberNew;
			userName=userNameNew;
			passwordSPA=passwordSPANew;

		}
		
		public struct balance1Response
		{


			public decimal balance;
			public string transactionId;
			public int errorCode;
			public string errorMessage;
			public string fullResponse;
			public string fullRequest;
			
		}



		public balance1Response balanceEnquiry1(string phoneNumber,string transactionId)  
		{
			balance1Response response=new balance1Response();
			try
			{
				string requestString="";
				

				IPAddress ipAddress = IPAddress.Parse(hostIP);
				IPEndPoint remoteEP = new IPEndPoint(ipAddress, portNumber);
				Socket client = new Socket(AddressFamily.InterNetwork,
					SocketType.Stream, ProtocolType.Tcp);

				requestString = "BAL1|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|SpaConnector\r\n";
				byte[] byteData = Encoding.ASCII.GetBytes(requestString);
				client.Connect (remoteEP);
				//TODO Check if port is open, close
				client.Send(byteData);
				byte[] bytes = new byte[1024];
				int bytesRec = client.Receive(bytes);
				client.Close();
				string received = Encoding.UTF7.GetString(bytes).Substring(0,bytesRec);
				string[] par = received.Split("|".ToCharArray()[0]) ;

				if (par[1] == "OK")
				{ 
					response.balance=System.Decimal.Parse( par[3].Substring(0,par[3].Length-2));
					response.errorCode=0;
					response.errorMessage="";
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
				
				}

				else

				{
					
					response.errorCode= int.Parse(par[3]);
					response.errorMessage= par[4].Substring(0,par[4].Length-2);
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
				
				}

				return(response);
			}
			catch (System.Net.Sockets.SocketException ex)
			{
				
				response.errorCode=ex.NativeErrorCode;
				response.errorMessage=ex.Message;
				return(response);}
		}
		

		public struct balance2Response
		{
			public string transactionId;
			public int errorCode;
			public string errorMessage;
			public string fullResponse;
			public string fullRequest;
			public decimal balance;
			public string expirationDate;
			public string freeMinutes;
			public string freeSeconds;
			public string balance1;
			public string expirationDate1;
			public string balance2;
			public string expirationDate2;
			public string plan;


		}
		
		public balance2Response balanceEnquiry2(string phoneNumber,string transactionId)  
		{
			balance2Response response=new balance2Response();
			try
			{
				string requestString="";
				

				IPAddress ipAddress = IPAddress.Parse(hostIP);
				IPEndPoint remoteEP = new IPEndPoint(ipAddress, portNumber);
				Socket client = new Socket(AddressFamily.InterNetwork,
					SocketType.Stream, ProtocolType.Tcp);

				requestString = "BAL2|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|SpaConnector\r\n";
				
				//requestString = "BAL3|metawallet|walmet3942|3|59170849072|50|BS|c1\r\n";
				//requestString = "DISCNT|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				//requestString = "DISCNT2|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				
				byte[] byteData = Encoding.ASCII.GetBytes(requestString);
				client.Connect (remoteEP);
				//TODO Check if port is open, close
				client.Send(byteData);
				byte[] bytes = new byte[1024];
				int bytesRec = client.Receive(bytes);
				client.Close();
				string received = Encoding.UTF7.GetString(bytes).Substring(0,bytesRec);
				string[] par = received.Split("|".ToCharArray()[0]) ;

				if (par[1] == "OK")
				{ 
					response.errorCode=0;
					response.errorMessage="";
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
					response.balance=response.balance=System.Decimal.Parse( par[3]);
					response.expirationDate=par[4];
					response.freeMinutes=par[5];
					response.freeSeconds=par[6];
					response.balance1=par[7];
					response.expirationDate1=par[8];
					response.balance2=par[9];
					response.expirationDate2=par[10];
					response.plan=par[11].Substring(0,par[11].Length-2);
				}

				else

				{
					response.errorCode= int.Parse(par[3]);
					response.errorMessage= par[4].Substring(0,par[4].Length-2);
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
					

				}

				return(response);
			}
			catch (System.Net.Sockets.SocketException ex)
			{
				response.errorCode=ex.NativeErrorCode;
				response.errorMessage=ex.Message;
				return(response);}
		}
		
	

		public struct balance3Response
		{
			public string transactionId;
			public int errorCode;
			public string errorMessage;
			public string fullResponse;
			public string fullRequest;
			public string enoughCredit;
		}
		public balance3Response balanceEnquiry3(string phoneNumber,string transactionId,decimal ammount)  
		{
			balance3Response response=new balance3Response();
			try
			{
				string requestString="";
				

				IPAddress ipAddress = IPAddress.Parse(hostIP);
				IPEndPoint remoteEP = new IPEndPoint(ipAddress, portNumber);
				Socket client = new Socket(AddressFamily.InterNetwork,
					SocketType.Stream, ProtocolType.Tcp);

				//requestString = "BAL2|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|SpaConnector\r\n";


				requestString = "BAL3|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|"+ammount.ToString()+"|BS|SpaConnector\r\n";
				


				//requestString = "DISCNT|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				//requestString = "DISCNT2|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				
				byte[] byteData = Encoding.ASCII.GetBytes(requestString);
				client.Connect (remoteEP);
				//TODO Check if port is open, close
				client.Send(byteData);
				byte[] bytes = new byte[1024];
				int bytesRec = client.Receive(bytes);
				client.Close();
				string received = Encoding.UTF7.GetString(bytes).Substring(0,bytesRec);
				string[] par = received.Split("|".ToCharArray()[0]) ;

				if (par[1] == "OK")
				{ 
					response.errorCode=0;
					response.errorMessage="";
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
					response.enoughCredit=par[3].Substring(0,par[3].Length-2);
				}

				else

				{
					response.errorCode= int.Parse(par[3]);
					response.errorMessage= par[4].Substring(0,par[4].Length-2);
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];

				}

				return(response);
			}
			catch (System.Net.Sockets.SocketException ex)
			{
				response.errorCode=ex.NativeErrorCode;
				response.errorMessage=ex.Message;
				return(response);}
		}


		public struct balance4Response
		{
			public string transactionId;
			public int errorCode;
			public string errorMessage;
			public string fullResponse;
			public string fullRequest;
			public decimal balance;
			public string expirationDate;
			public string freeMinutes;
			public string freeSeconds;
			public string balance1;
			public string expirationDate1;
			public string balance2;
			public string expirationDate2;
			public string plan;
			public string serviceProvider;
			public string state;



		}
		
		public balance4Response balanceEnquiry4(string phoneNumber,string transactionId)  
		{
			balance4Response response=new balance4Response();
			try
			{
				string requestString="";
				

				IPAddress ipAddress = IPAddress.Parse(hostIP);
				IPEndPoint remoteEP = new IPEndPoint(ipAddress, portNumber);
				Socket client = new Socket(AddressFamily.InterNetwork,
					SocketType.Stream, ProtocolType.Tcp);

				requestString = "BAL4|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|SpaConnector\r\n";
				
				//requestString = "BAL3|metawallet|walmet3942|3|59170849072|50|BS|c1\r\n";
				//requestString = "DISCNT|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				//requestString = "DISCNT2|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				
				byte[] byteData = Encoding.ASCII.GetBytes(requestString);
				client.Connect (remoteEP);
				//TODO Check if port is open, close
				client.Send(byteData);
				byte[] bytes = new byte[1024];
				int bytesRec = client.Receive(bytes);
				client.Close();
				string received = Encoding.UTF7.GetString(bytes).Substring(0,bytesRec);
				string[] par = received.Split("|".ToCharArray()[0]) ;

				if (par[1] == "OK")
				{ 
					response.errorCode=0;
					response.errorMessage="";
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
					response.balance=response.balance=System.Decimal.Parse( par[3]);
					response.expirationDate=par[4];
					response.freeMinutes=par[5];
					response.freeSeconds=par[6];
					response.balance1=par[7];
					response.expirationDate1=par[8];
					response.balance2=par[9];
					response.expirationDate2=par[10];
					response.plan=par[11];
					response.serviceProvider=par[12];
					response.state=par[13].Substring(0,par[13].Length-2);
				}

				else

				{
					response.errorCode= int.Parse(par[3]);
					response.errorMessage= par[4].Substring(0,par[4].Length-2);
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];

				}

				return(response);
			}
			catch (System.Net.Sockets.SocketException ex)
			{
				response.errorCode=ex.NativeErrorCode;
				response.errorMessage=ex.Message;
				return(response);}
		}

		public struct discount2Response
		{
			public string transactionId;
			public int errorCode;
			public string errorMessage;
			public string fullResponse;
			public string fullRequest;
			public string success;

		}
		public discount2Response discount2(string phoneNumber,string transactionId,string tariffCode)  
		{
			discount2Response response=new discount2Response();
			try
			{
				string requestString="";
				

				IPAddress ipAddress = IPAddress.Parse(hostIP);
				IPEndPoint remoteEP = new IPEndPoint(ipAddress, portNumber);
				Socket client = new Socket(AddressFamily.InterNetwork,
					SocketType.Stream, ProtocolType.Tcp);


				//requestString = "DISCNT|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				//requestString = "DISCNT2|metawallet|walmet3942|3|59170849072|1234001|test\r\n";
				requestString = "DISCNT2|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|"+tariffCode+"|SpaConnector\r\n";
				
				byte[] byteData = Encoding.ASCII.GetBytes(requestString);
				client.Connect (remoteEP);
				//TODO Check if port is open, close
				client.Send(byteData);
				byte[] bytes = new byte[1024];
				int bytesRec = client.Receive(bytes);
				client.Close();
				string received = Encoding.UTF7.GetString(bytes).Substring(0,bytesRec);
				string[] par = received.Split("|".ToCharArray()[0]) ;

				if (par[1] == "OK")
				{ 
					response.errorCode=0;
					response.errorMessage="";
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2].Substring(0,par[2].Length-2);
					response.success="YES";
				}

				else

				{
					response.errorCode= int.Parse(par[3]);
					response.errorMessage= par[4].Substring(0,par[4].Length-2);
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
					response.success="NO";

				}

				return(response);
			}
			catch (System.Net.Sockets.SocketException ex)
			{
				response.errorCode=ex.NativeErrorCode;
				response.errorMessage=ex.Message;
				response.success="NO";

				return(response);}
		}


		public struct discount1Response
		{
			public string transactionId;
			public int errorCode;
			public string errorMessage;
			public string fullResponse;
			public string fullRequest;
			public string success;

		}
		public discount1Response discount1(string phoneNumber,string transactionId,decimal ammount)  
		{
			discount1Response response=new discount1Response();
			try
			{
				string requestString="";
				

				IPAddress ipAddress = IPAddress.Parse(hostIP);
				IPEndPoint remoteEP = new IPEndPoint(ipAddress, portNumber);
				Socket client = new Socket(AddressFamily.InterNetwork,
					SocketType.Stream, ProtocolType.Tcp);


				//requestString = "DISCNT|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				//requestString = "DISCNT2|metawallet|walmet3942|3|59170849072|1234001|test\r\n";
				requestString = "DISCNT|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|-"+ammount.ToString()+"|BS|SpaConnector\r\n";
				
				byte[] byteData = Encoding.ASCII.GetBytes(requestString);
				client.Connect (remoteEP);
				//TODO Check if port is open, close
				client.Send(byteData);
				byte[] bytes = new byte[1024];
				int bytesRec = client.Receive(bytes);
				client.Close();
				string received = Encoding.UTF7.GetString(bytes).Substring(0,bytesRec);
				string[] par = received.Split("|".ToCharArray()[0]) ;

				if (par[1] == "OK")
				{ 
					response.errorCode=0;
					response.errorMessage="";
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2].Substring(0,par[2].Length-2);
					response.success="YES";
				}

				else

				{
					response.errorCode= int.Parse(par[3]);
					response.errorMessage= par[4].Substring(0,par[4].Length-2);
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
					response.success="NO";

				}

				return(response);
			}
			catch (System.Net.Sockets.SocketException ex)
			{
				response.errorCode=ex.NativeErrorCode;
				response.errorMessage=ex.Message;
				response.success="NO";

				return(response);}
		}

		public struct addCreditResponse
		{


			public string transactionId;
			public int errorCode;
			public string errorMessage;
			public string fullResponse;
			public string fullRequest;
			public string success;
			public string fiscalId;
			public string invoiceNumber;
			public string orderNumber;
			public string invoiceSerialNumber;
			public string companyName;
			public string expirationDateLiteralSpanish;



		}
		public addCreditResponse addCredit(string phoneNumber,string transactionId,decimal ammount,string fiscalName,string fiscalId,string machineId)  
		{
			addCreditResponse response=new addCreditResponse();
			try
			{
				string requestString="";
				

				IPAddress ipAddress = IPAddress.Parse(hostIP);
				IPEndPoint remoteEP = new IPEndPoint(ipAddress, portNumber);
				Socket client = new Socket(AddressFamily.InterNetwork,
					SocketType.Stream, ProtocolType.Tcp);


				//requestString = "DISCNT|metawallet|walmet3942|3|59170849072|-1|BS|test\r\n";
				//requestString = "DISCNT2|metawallet|walmet3942|3|59170849072|1234001|test\r\n";
				requestString = "CHRG|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|"+ammount.ToString()+"|BS|SpaConnector|"+fiscalName+"|"+fiscalId+"|"+machineId+"\r\n";
				
				byte[] byteData = Encoding.ASCII.GetBytes(requestString);
				client.Connect (remoteEP);
				//TODO Check if port is open, close
				client.Send(byteData);
				byte[] bytes = new byte[1024];
				int bytesRec = client.Receive(bytes);
				client.Close();
				string received = Encoding.UTF7.GetString(bytes).Substring(0,bytesRec);
				string[] par = received.Split("|".ToCharArray()[0]) ;

				if (par[1] == "OK")
				{ 
					response.errorCode=0;
					response.errorMessage="";
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
					response.success="YES";

					response.fiscalId=par[3];
					response.invoiceNumber=par[4];
					response.orderNumber=par[5];
					response.invoiceSerialNumber=par[6];
					response.companyName=par[7];
					response.expirationDateLiteralSpanish=par[8].Substring(0,par[8].Length-2);
				}

				else

				{
					response.errorCode= int.Parse(par[3]);
					response.errorMessage= par[4].Substring(0,par[4].Length-2);
					response.fullResponse=received;
					response.fullRequest=requestString;
					response.transactionId=par[2];
					response.success="NO";


				}

				return(response);
			}
			catch (System.Net.Sockets.SocketException ex)
			{
				response.errorCode=ex.NativeErrorCode;
				response.errorMessage=ex.Message;
				response.fullResponse="";
				response.fullRequest="";
				response.transactionId="";
				response.success="NO";

				return(response);}
		}
	}
}


