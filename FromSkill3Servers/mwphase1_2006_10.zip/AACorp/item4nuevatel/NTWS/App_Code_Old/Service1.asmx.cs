using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace ntws
{
	/// <summary>
	/// Summary description for Service1.
	/// </summary>
	public class Service1 : System.Web.Services.WebService
	{
		public Service1()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		public static String ReadSetting(String key)

		{
			try
			{
				object setting = System.Configuration.ConfigurationSettings.AppSettings[key];
				if(setting == null)
				{
					setting="";
				}
				return (setting.ToString());
			}
			catch
			{
				return ("");
			}
		}


		[WebMethod]
	public SpaConnector.balance1Response wsbalanceEnquiry1(string PhoneNumber,string TransactionId)
	{
			string hostIP = ReadSetting("hostIP");
			int portNumber = System.Int32.Parse( ReadSetting("portNumber"));
			string userName = ReadSetting("userName");
			string passwordSPA= ReadSetting("passwordSPA");
			SpaConnector spa = new SpaConnector(hostIP,portNumber,userName,passwordSPA);
			SpaConnector.balance1Response response;
			response=spa.balanceEnquiry1(PhoneNumber,TransactionId);
			return (response);
		}

		[WebMethod]
		public SpaConnector.balance2Response wsbalanceEnquiry2(string PhoneNumber,string TransactionId)
		{
			string hostIP = ReadSetting("hostIP");
			int portNumber = System.Int32.Parse( ReadSetting("portNumber"));
			string userName = ReadSetting("userName");
			string passwordSPA= ReadSetting("passwordSPA");
			SpaConnector spa = new SpaConnector(hostIP,portNumber,userName,passwordSPA);
			SpaConnector.balance2Response response;
			response=spa.balanceEnquiry2(PhoneNumber,TransactionId);
			return (response);
		}

		[WebMethod]
		public SpaConnector.balance3Response wsbalanceEnquiry3(string PhoneNumber,string TransactionId,decimal Ammount)
		{
			string hostIP = ReadSetting("hostIP");
			int portNumber = System.Int32.Parse( ReadSetting("portNumber"));
			string userName = ReadSetting("userName");
			string passwordSPA= ReadSetting("passwordSPA");
			SpaConnector spa = new SpaConnector(hostIP,portNumber,userName,passwordSPA);
			SpaConnector.balance3Response response;
			response=spa.balanceEnquiry3(PhoneNumber,TransactionId,Ammount);
			return (response);
		}

		[WebMethod]
		public SpaConnector.balance4Response wsbalanceEnquiry4(string PhoneNumber,string TransactionId)
		{
			
			string hostIP = ReadSetting("hostIP");
			int portNumber = System.Int32.Parse( ReadSetting("portNumber"));
			string userName = ReadSetting("userName");
			string passwordSPA= ReadSetting("passwordSPA");
			SpaConnector spa = new SpaConnector(hostIP,portNumber,userName,passwordSPA);
			SpaConnector.balance4Response response;
			response=spa.balanceEnquiry4(PhoneNumber,TransactionId);
			return (response);
		}

		[WebMethod]
		public SpaConnector.discount1Response wsbalanceDiscount1(string PhoneNumber,string TransactionId,decimal Ammount)
		{
			string hostIP = ReadSetting("hostIP");
			int portNumber = System.Int32.Parse( ReadSetting("portNumber"));
			string userName = ReadSetting("userName");
			string passwordSPA= ReadSetting("passwordSPA");
			SpaConnector spa = new SpaConnector(hostIP,portNumber,userName,passwordSPA);
			SpaConnector.discount1Response response;
			response=spa.discount1(PhoneNumber,TransactionId,Ammount);
			return (response);
		}

		[WebMethod]
		public SpaConnector.discount2Response wsbalanceDiscount2(string PhoneNumber,string TransactionId,string TariffCode)
		{
			string hostIP = ReadSetting("hostIP");
			int portNumber = System.Int32.Parse( ReadSetting("portNumber"));
			string userName = ReadSetting("userName");
			string passwordSPA= ReadSetting("passwordSPA");
			SpaConnector spa = new SpaConnector(hostIP,portNumber,userName,passwordSPA);
			SpaConnector.discount2Response response;
			response=spa.discount2(PhoneNumber,TransactionId,TariffCode);
			return (response);
		}

		[WebMethod]
		public SpaConnector.addCreditResponse wsAddCredit(string PhoneNumber,string TransactionId,decimal Ammount,string FiscalName,string FiscalId,string MachineId)
		{
			string hostIP = ReadSetting("hostIP");
			int portNumber = System.Int32.Parse( ReadSetting("portNumber"));
			string userName = ReadSetting("userName");
			string passwordSPA= ReadSetting("passwordSPA");
			SpaConnector spa = new SpaConnector(hostIP,portNumber,userName,passwordSPA);
			SpaConnector.addCreditResponse response;
			response=spa.addCredit(PhoneNumber,TransactionId,Ammount,FiscalName,FiscalId,MachineId);
			return (response);
		}
	}
}
