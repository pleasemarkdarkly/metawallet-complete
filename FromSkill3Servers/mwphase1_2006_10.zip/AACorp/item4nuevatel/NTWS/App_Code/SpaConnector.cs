using System;

// Aditional namespaces
using System.Net.Sockets;
using System.Net;
using System.Text;


namespace ntws
{
	/// <summary>
	/// Summary description for SpaConnector.
	/// </summary>
	public class SpaConnector
	{
		
		private string hostIP="";
		private int portNumber=0;
		private string userName="";
		private string passwordSPA="";


		
		public SpaConnector(string hostIPNew,int portNumberNew,string userNameNew,string passwordSPANew)
		{
			
			hostIP=hostIPNew;
			portNumber=portNumberNew;
			userName=userNameNew;
			passwordSPA=passwordSPANew;

		}
		
		public struct balance1Response
		{
			public decimal balance;
			public string transactionId;
			public int errorCode;
			public string errorMessage;
			public string fullResponse;
			public string fullRequest;
		}


		public balance1Response balanceEnquiry1(string phoneNumber,string transactionId)  
		{
			string requestString="";
			balance1Response response;

			IPAddress ipAddress = IPAddress.Parse(hostIP);
			IPEndPoint remoteEP = new IPEndPoint(ipAddress, portNumber);
			Socket client = new Socket(AddressFamily.InterNetwork,
				SocketType.Stream, ProtocolType.Tcp);

			requestString = "BAL1|"+userName+"|"+passwordSPA+"|"+transactionId+"|"+phoneNumber+"|SpaConnector\r\n";
			byte[] byteData = Encoding.ASCII.GetBytes(requestString);
			client.Connect (remoteEP);
			//TODO Check if port is open, close
			client.Send(byteData);
			byte[] bytes = new byte[1024];
			int bytesRec = client.Receive(bytes);
			client.Close();
			string received = Encoding.UTF7.GetString(bytes).Substring(0,bytesRec);
			string[] par = received.Split("|".ToCharArray()[0]) ;

			if (par[1] == "OK")
			{ 
				response.balance=System.Decimal.Parse( par[3].Substring(0,par[3].Length-2));
				response.errorCode=0;
				response.errorMessage="";
				response.fullResponse=received;
				response.fullRequest=requestString;
				response.transactionId=par[2];
			}

			else

			{
				response.balance=0;
				response.errorCode= int.Parse(par[3]);
				response.errorMessage= par[4].Substring(0,par[4].Length-2);
				response.fullResponse=received;
				response.fullRequest=requestString;
				response.transactionId=par[2];
			}

			return(response);
			
		}
	}
}
