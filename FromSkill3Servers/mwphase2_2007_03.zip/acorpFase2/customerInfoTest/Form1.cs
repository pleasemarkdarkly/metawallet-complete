using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace customerInfoTest
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }
    string snull(string s)
    { 
      if (s==null)
      {
        return string.Empty;
      }
      else
      {
        return s;
      }
    }
    private void button1_Click(object sender, EventArgs e)
    {
      try
      {
        this.textBox1.Text = string.Empty;
        clientInformation.ClientInfoService c1 = new clientInformation.ClientInfoService();
        clientInformation.consumptionEntityServicesForClient r1;
        r1 = c1.getInformation("vivaClient", "0m3g41nf0", this.textBox2.Text);
        try
        {
          this.textBox1.Text += snull(r1.billingPersonDateOfBirth.ToString()) + "\r\n";
        }
        catch { }
        this.textBox1.Text += snull(r1.billingPersonDocument) + "\r\n";
        this.textBox1.Text += snull(r1.billingPersonHouseAddress) + "\r\n";
        this.textBox1.Text += snull(r1.billingPersonNit) + "\r\n";
        this.textBox1.Text += snull(r1.billingPersonSex) + "\r\n";
        this.textBox1.Text += snull(r1.billingPersonType) + "\r\n";
        this.textBox1.Text += snull(r1.billingPersonWorkAddress) + "\r\n";
        this.textBox1.Text += snull(r1.billingPersonFullName) + "\r\n";

        try
        {
          this.textBox1.Text += snull(r1.consEntityDateOfBirth.ToString()) + "\r\n";
        }
        catch { }
        this.textBox1.Text += snull(r1.consEntityDocument) + "\r\n";
        this.textBox1.Text += snull(r1.consEntityHouseAddress) + "\r\n";
        this.textBox1.Text += snull(r1.consEntityLineState) + "\r\n";
        this.textBox1.Text += snull(r1.consEntityNit) + "\r\n";
        this.textBox1.Text += snull(r1.consEntityPersonType) + "\r\n";
        this.textBox1.Text += snull(r1.consEntityPhoneNumber) + "\r\n";
        this.textBox1.Text += snull(r1.consEntityPlan) + "\r\n";
        this.textBox1.Text += snull(r1.consEntitySex) + "\r\n";
        this.textBox1.Text += snull(r1.consEntityWorkAddress) + "\r\n";
        this.textBox1.Text += snull(r1.consEntityFullName) + "\r\n";
        try
        {
          this.textBox1.Text += snull(r1.clientDateOfBirth.ToString()) + "\r\n";
        }
        catch { }
        this.textBox1.Text += snull(r1.clientDocument) + "\r\n";
        this.textBox1.Text += snull(r1.clientHouseAddress) + "\r\n";
        this.textBox1.Text += snull(r1.clientNit) + "\r\n";
        this.textBox1.Text += snull(r1.clientPersonType) + "\r\n";
        this.textBox1.Text += snull(r1.clientSex) + "\r\n";
        this.textBox1.Text += snull(r1.clientWorkAddress) + "\r\n";
        this.textBox1.Text += snull(r1.clientFullName) + "\r\n";
      }
      catch (Exception ex)
      {
        this.textBox1.Text += ex.ToString();
      }
    }
  }
}