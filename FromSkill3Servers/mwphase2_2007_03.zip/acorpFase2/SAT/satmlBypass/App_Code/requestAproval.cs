using System;
using System.Web;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data.SqlClient;
using System.Net;
using System.Text;
/// <summary>
/// Summary description for requestAproval
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class requestAproval : System.Web.Services.WebService
{
  public requestAproval()
  {

    //Uncomment the following line if using designed components 
    //InitializeComponent(); 
  }
  [WebMethod]
  public string processSMS(long internalId, string sender, string receiver, string text, string connectionId)
  {
    //return values:
    //an empty string=do not send a response, do not mark the message as processed
    //"!"=mark the message processed, do not send any response
    //any other string wil be sent as a rsponse, if it's longer that one SMS, it will be split
    //implement you application here, good luck
    text = text.Replace("+", " ");
    text = text.Replace("-", " ");
    text = text.Replace("_", " ");
    text = text.Replace("\n", " ");
    text = text.Replace("\r", " ");
    text = text.Replace("  ", " ");
    sender = sender.Replace("+", "");
    if (sender.Length == 8) sender = "591" + sender;
    if (receiver == "+25") receiver = "25";
    if (text.Length > 2 & text.IndexOf(" ") == -1)
    { 
      text=text.Substring(0,1) + " " + text.Substring(1);
    }
    string[] parts;
    int PIN;
    parts = text.Split(" ".ToCharArray());
    if (parts.Length != 2)
    {
      return ("Formato de mensaje incorrecto");
    }
    if (int.TryParse(parts[1], out PIN))
    {
      string connectionString = "workstation id=SMSdevServer;packet size=4096;user id=smsIOusr;data source=MWSERVER;persist security info=True;initial catalog=smsIO;password=fVhAUcSq7tEm";
      string command = "spUpdateAproval2 '@@ori@@', '@@cus@@', '@@sta@@'";
      string transactionID;
      string URL = "http://70.98.63.130/MW.MComm.Phone.WebUI/RejectOrderResponse.aspx";
      command = command.Replace("@@cus@@", sender);
      command = command.Replace("@@ori@@", receiver);
      command = command.Replace("@@sta@@", parts[0]);
      SqlConnection sqlCon = new SqlConnection(connectionString);
      SqlCommand sqlCom = new SqlCommand(command, sqlCon);
      sqlCon.Open();
      transactionID = sqlCom.ExecuteScalar().ToString();
      if (transactionID != string.Empty)
      {
        if (parts[0].ToLower() == "a")
        {
          URL = "http://70.98.63.130/MW.MComm.Phone.WebUI/ApproveOrderResponse.aspx";
        }
        else if (parts[0].ToLower() == "r")
        {
          URL = "http://70.98.63.130/MW.MComm.Phone.WebUI/RejectOrderResponse.aspx";
        }
        WebClient web1 = new WebClient();
        System.Collections.Specialized.NameValueCollection values = new System.Collections.Specialized.NameValueCollection();
        values.Add("OrderID", transactionID);
        values.Add("Origen", sender);
        values.Add("PIN", PIN.ToString());
        byte[] responseB;
        char[] responseC;
        string responseS = string.Empty;
        responseB = web1.UploadValues(URL, values);
        ASCIIEncoding AE = new ASCIIEncoding();
        responseC = AE.GetChars(responseB);
       
        foreach (char c1 in responseC)
        {
            try
            {
                responseS += c1;
            }
            catch { responseS += "?"; }
          }//<satml> <card> <p> <h3>
        responseS = responseS.Replace("<satml>","");
        responseS = responseS.Replace("<card>", "");
        responseS = responseS.Replace("<p>", "");
        responseS = responseS.Replace("<h3>", "");
        responseS = responseS.Replace("</satml>", "");
        responseS = responseS.Replace("</card>", "");
        responseS = responseS.Replace("</p>", "");
        responseS = responseS.Replace("</h3>", "");
        responseS = responseS.Replace("<br/>", "");
        responseS = responseS.Replace("<do type=\"accept\" label=\"P??gina Anterior\">", "");
        responseS = responseS.Replace("</do>", "");
        responseS = responseS.Replace("<prev/>", "");
        responseS = responseS.Replace("<prev />", "");
        responseS = responseS.Replace("<exit />", "");
        responseS = responseS.Replace("<br />", "");
        responseS = responseS.Replace("   ", " ");
        responseS = responseS.Replace("  ", " ");
        return responseS;
      }
      else
      { return "No hay transacciones para aprobar o rechazar"; }
    }
      return ("Formato de mensaje incorrecto");
   }
  [WebMethod]
  public string getAprovalAndPin(string transactionID,  string customerPhone)
  {
    try
    {
      string originPhone = "25";
      string SMS = "Aprobar o rechazar la transacci�n (responda A mas su pin o R mas su pin)";
      string connectionString = "workstation id=SMSdevServer;packet size=4096;user id=smsIOusr;data source=MWSERVER;persist security info=True;initial catalog=smsIO;password=fVhAUcSq7tEm";
      string command = "INSERT INTO aprovalRequests(transacionId, originPhone, customerPhone)VALUES('@@t@@','@@o@@','@@c@@')";
      smsSender.smsSender sender = new smsSender.smsSender();
      sender.sendSMS(originPhone, customerPhone, SMS);
      SqlConnection sqlCon = new SqlConnection(connectionString);
      SqlCommand sqlCom = new SqlCommand("", sqlCon);
      command = command.Replace("@@c@@", customerPhone);
      command = command.Replace("@@o@@", originPhone);
      command = command.Replace("@@t@@", transactionID);
      sqlCon.Open();
      sqlCom.CommandText = command;
      sqlCom.ExecuteNonQuery();
      return "";
    }
    catch (Exception ex)
    {
      return ex.Message;
    }

  }
  [WebMethod]
  public string getAprovalAndPin2(string transactionID, string origen, string destino)
  {
    try
    {
      string customerPhone=origen;
      string originPhone=destino;
      string SMS = "Aprobar o rechazar la transaccion (responda A o R mas su pin) " + transactionID;
      string connectionString = "workstation id=SMSdevServer;packet size=4096;user id=smsIOusr;data source=MWSERVER;persist security info=True;initial catalog=smsIO;password=fVhAUcSq7tEm";
      string command = "INSERT INTO aprovalRequests(transacionId, originPhone, customerPhone)VALUES('@@t@@','@@o@@','@@c@@')";
      smsSender.smsSender sender = new smsSender.smsSender();
      sender.sendSMS(originPhone, customerPhone, SMS);
      SqlConnection sqlCon = new SqlConnection(connectionString);
      SqlCommand sqlCom = new SqlCommand("", sqlCon);
      command = command.Replace("@@c@@", customerPhone);
      command = command.Replace("@@o@@", originPhone);
      command = command.Replace("@@t@@", transactionID);
      sqlCon.Open();
      sqlCom.CommandText = command;
      sqlCom.ExecuteNonQuery();
      return "";
    }
    catch (Exception ex)
    {
      return ex.Message;
    }

  }
}

