Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data.SqlClient
Imports System.Net

<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class Servicios
    Inherits System.Web.Services.WebService

    <WebMethod(EnableSession:=True)> _
    Public Function CustomerInformation(ByVal CustomerCode As String, ByVal CustomerPin As String, _
                                        ByVal AccountAuthorizationCode As String, ByVal AuditId As String) As String

        Dim lWSBGA As New WSBGA.Servicios
        Return lWSBGA.CustomerInformation(CustomerCode, CustomerPin, AccountAuthorizationCode, AuditId)
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Function AccountInformation(ByVal CustomerCode As String, ByVal CustomerPin As String, _
                                       ByVal AccountAuthorizationCode As String, ByVal AccountNumber As String, _
                                       ByVal AuditId As String) As String

        Dim lWSBGA As New WSBGA.Servicios
        Return lWSBGA.AccountInformation(CustomerCode, CustomerPin, AccountAuthorizationCode, AccountNumber, AuditId)
    End Function

    <WebMethod(EnableSession:=True)> _
       Public Function CurrencyConversionCalculation(ByVal CustomerCode As String, ByVal OriginalCurrency As String, _
                                                     ByVal DestinationCurrency As String, ByVal Ammount As String, _
                                                     ByVal Type As String) As String

        Dim lWSBGA As New WSBGA.Servicios
        Return lWSBGA.CurrencyConversionCalculation(CustomerCode, OriginalCurrency, DestinationCurrency, Ammount, Type)
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Function AccountTransferSB(ByVal CustomerCode As String, ByVal AccountPin As String, _
                                      ByVal AccountAuthorizationCode As String, ByVal OrigenAccount As String, _
                                      ByVal DestinationAccount As String, _
                                      ByVal AuditId As String, ByVal Ammount As String, _
                                      ByVal TransactionCurrency As String) As String

        Dim lWSBGA As New WSBGA.Servicios
        Return lWSBGA.AccountTransferSB(CustomerCode, AccountPin, AccountAuthorizationCode, OrigenAccount, DestinationAccount, AuditId, Ammount, TransactionCurrency)
    End Function

End Class
