Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.Data.SqlClient
Imports System.Net

<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class Servicios
    Inherits System.Web.Services.WebService

    <WebMethod(EnableSession:=True)> _
    Public Function CustomerInformation(ByVal CustomerCode As String, ByVal CustomerPin As String, _
                                        ByVal AccountAuthorizationCode As String, ByVal AuditId As String) As String

        Dim lWSBGA As New WSBGA.Servicios
        Return lWSBGA.CustomerInformation(CustomerCode, CustomerPin, AccountAuthorizationCode, AuditId)
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Function AccountInformation(ByVal CustomerCode As String, ByVal CustomerPin As String, _
                                       ByVal AccountAuthorizationCode As String, ByVal AccountNumber As String, _
                                       ByVal AuditId As String) As String

        Dim lWSBGA As New WSBGA.Servicios
        Return lWSBGA.AccountInformation(CustomerCode, CustomerPin, AccountAuthorizationCode, AccountNumber, AuditId)
    End Function

    <WebMethod(EnableSession:=True)> _
       Public Function CurrencyConversionCalculation(ByVal CustomerCode As String, ByVal OriginalCurrency As String, _
                                                     ByVal DestinationCurrency As String, ByVal Ammount As String, _
                                                     ByVal Type As String) As String

        Dim lWSBGA As New WSBGA.Servicios
        Return lWSBGA.CurrencyConversionCalculation(CustomerCode, OriginalCurrency, DestinationCurrency, Ammount, Type)
    End Function

    <WebMethod(EnableSession:=True)> _
    Public Function AccountTransferSB(ByVal CustomerCode As String, ByVal AccountPin As String, _
                                      ByVal AccountCode As String, ByVal DestinationAccount As String, _
                                      ByVal AuditId As String, ByVal Ammount As String, _
                                      ByVal TransactionCurrency As String) As String

        Dim lWSBGA As New WSBGA.Servicios
        'Return lWSBGA.AccountTransferSB(CustomerCode, AccountPin, AccountCode, DestinationAccount, AuditId, Ammount, TransactionCurrency)
        Return " en construccion"
    End Function

    '<WebMethod(EnableSession:=True)> _
    'Public Function AccountTransferSB(ByVal CustomerCode As String, ByVal AccountPin As String, _
    '                                  ByVal AccountCode As String, ByVal DestinationAccount As String, _
    '                                  ByVal AuditId As String, ByVal Ammount As String, ByVal TransactionCurrency As String) As String


    '    '### Declaracion de variables output 
    '    Dim TaxOriginAccount As Decimal = 0
    '    Dim TaxDestinationAccount As Decimal = 0
    '    'Dim ConfirmationCode As String = ""  campo eliminado debido a que el banco no maneja este 

    '    '### Validacion de inputs 
    '    'If (ValidateInputs(CustomerCode, "CustomerCode", 0)) And (ValidateInputs(AccountPin, "PIN", 0)) And _
    '    '   (ValidateInputs(AccountCode, "AccountCode", 0)) And (ValidateInputs(DestinationAccount, "DestinationAccount", 0)) And _
    '    '   (ValidateInputs(Ammount, "Ammount", 1)) Then


    '    'Dim lclsCtmctM As New CapaNegocios.clsCtmctM

    '    ''### Cargar los valores de los Par�metros Input
    '    'lclsCtmctM.gDatos.Cage = CustomerCode
    '    'lclsCtmctM.gDatos.Cage = AccountPin
    '    'lclsCtmctM.gDatos.Cage = AccountCode
    '    'lclsCtmctM.gDatos.Cage = DestinationAccount
    '    'lclsCtmctM.gDatos.Paud = AuditId
    '    'lclsCtmctM.gDatos.Npin = Ammount
    '    'lclsCtmctM.gDatos.Pint = TransactionCurrency


    '    ''### Realizar el Proceso
    '    'lclsCtmctM.AccountInformation()

    '    'If lclsCtmctM.gDatos.Estado.Estado = [Global].clsEstado.enumEstado.enOk Then
    '    '    '### Cargar los Valores de los Par�metros Output
    '    '    TaxOriginAccount = 
    '    '    TaxDestinationAccount = 
    '    '    ConfirmationCode = 
    '    '    ErrorCode = 0
    '    '    ErrorDescription = "OK"
    '    'Else
    '    '    ErrorCode = lclsCtmctM.gDatos.Estado.CodigoMsg
    '    '    ErrorDescription = 
    '    '    If ErrorCode = [Global].clsEnum.EnumMensajes.enDatoIngresadoIncorrecto Then
    '    '        ErrorDescription = "Dato de Entrada NO v�lido: " & ErrorDescription
    '    '    End If
    '    'End If

    '    'End If

    '    'Return "<TaxOriginAccount: " + TaxOriginAccount.ToString + ">" + _
    '    '"<TaxDestinationAccount: " + TaxDestinationAccount.ToString + ">" + _
    '    '"<ErrorCode: " + ErrorCode + ">" + _
    '    '"<ErrorDescription: " + ErrorDescription + ">"
    '    ''"<ConfirmationCode: " + ConfirmationCode + ">" + _

    '    Return ""
    'End Function



    '<WebMethod(EnableSession:=True)> _
    '    Public Function AccountCredit(ByVal AccountCode As String, ByVal Ammount As String, _
    '                                  ByVal TransactionCurrency As String, ByVal AuditId As String) As String

    '    ''### Declaracion de variables output 
    '    'Dim Taxes As Decimal = 0
    '    'Dim FinalMsg As String = ""

    '    ''### Validacion de inputs 
    '    'If ValidateInputs(Ammount, "Ammount", 1) Then
    '    '    If Ammount > 0 Then
    '    '        FinalMsg = AccountTransferSB("codigo_org", "pin_org", "codigoCuenta_org", AccountCode, AuditId, Ammount, TransactionCurrency)
    '    '    Else
    '    '        ErrorCode = 1111
    '    '        ErrorDescription = "El monto ingresado debe ser positivo"
    '    '    End If

    '    'End If

    '    'Return CStr(IIf(FinalMsg = "", "<Taxes: " + Taxes.ToString + ">" + _
    '    '                  "<ErrorCode: " + ErrorCode + ">" + _
    '    '                  "<ErrorDescription: " + ErrorDescription + ">", FinalMsg))

    '    Return ""
    'End Function

    '<WebMethod(EnableSession:=True)> _
    '        Public Function AccountDedit(ByVal CustommerCode As String, ByVal AccountPin As String, _
    '                                     ByVal AccountCode As String, ByVal AuditId As String, _
    '                                     ByVal Ammount As String, ByVal TransactionCurrency As String) As String

    '    ' ''### Declaracion de variables output 
    '    ''Dim Taxes As Decimal = 0
    '    ''Dim FinalMsg As String = ""

    '    ' ''### Validacion de inputs 
    '    ''If (ValidateInputs(CustommerCode, "CustommerCode", 0)) And (ValidateInputs(Ammount, "Ammount", 1)) And _
    '    ''(ValidateInputs(AccountPin, "AccountPin", 0)) And (ValidateInputs(AccountCode, "AccountCode", 0)) Then
    '    ''    If Ammount > 0 Then
    '    ''        FinalMsg = AccountTransferSB(CustommerCode, AccountPin, AccountCode, "destinationAccount", AuditId, Ammount, TransactionCurrency)
    '    ''    Else
    '    ''        ErrorCode = 1111
    '    ''        ErrorDescription = "El monto ingresado debe ser positivo"
    '    ''    End If

    '    ''End If

    '    ''Return CStr(IIf(FinalMsg = "", "<Taxes: " + Taxes.ToString + ">" + "<ErrorCode: " + ErrorCode + ">" + _
    '    ''                  "<ErrorDescription: " + ErrorDescription + ">", FinalMsg))

    '    Return ""
    'End Function

    '<WebMethod(EnableSession:=True)> _
    'Public Function llamaPru() As String
    '    Dim valor As String = prueba("v1", "pruV2", "pruv3")

    '    Return valor
    'End Function

    'Public Function prueba(ByVal v1 As String, ByRef v2 As String, ByRef v3 As String) As String
    '    v2 = "v2 cambiado"
    '    v3 = "v3 cambiado"
    '    Return v2
    'End Function


    '<WebMethod(EnableSession:=True)> _
    '    Public Function AccountTransferEB(ByVal CustomerCode As Integer, ByVal AccountPin As Integer, _
    '                                      ByVal AccountAuthorizationCode As Integer, ByVal AccountNumber As Integer, _
    '                                      ByVal DestinationAccount As String, ByVal DestinationBankCode As String, _
    '                                      ByVal AuditId As String, ByVal Ammount As String, _
    '                                      ByVal TransactionCurrency As String, ByVal AddTax As Boolean, _
    '                                      ByRef EffectiveAmmount As String, ByRef ConfirmationCode As String, _
    '                                      ByRef ErrorCode As String, ByRef ErrorDescription As String) As String

    '    'Dim lClsGbageM As New CapaNegocios.clsGbageM

    '    Return ""
    'End Function

    '<WebMethod(EnableSession:=True)> _
    '    Public Function AccountTransferResult(ByVal AccountTransferResponse As String, ByVal AuditId As String, _
    '                                          ByVal TransferState As String, ByRef ConfirmationCode As String, _
    '                                          ByRef ErrorCode As String, ByRef ErrorDescription As String) As String

    '    'Dim lClsGbageM As New CapaNegocios.clsGbageM

    '    Return ""
    'End Function


    '<WebMethod(EnableSession:=True)> _
    '    Public Function BillPaymentQuery(ByVal CustomerCode As Integer, ByVal AccountPin As Integer, _
    '                                     ByVal AccountAuthorizationCode As Integer, ByVal RegisteredBillerId As String, _
    '                                     ByVal VendorCode As String, ByVal VendorName As String, _
    '                                     ByVal PendingBillsCount As String, ByVal PendingBillsAmmount As String, _
    '                                     ByVal PendingBillsCurrency As String, _
    '                                     ByRef ErrorCode As String, ByRef ErrorDescription As String) As String

    '    'Dim lClsGbageM As New CapaNegocios.clsGbageM

    '    Return ""
    'End Function

    '<WebMethod(EnableSession:=True)> _
    '    Public Function BillPaymentQueryByPendingBill(ByVal CustomerCode As Integer, ByVal AccountPin As Integer, _
    '                                                  ByVal AccountAuthorizationCode As Integer, ByVal RegisteredBillerId As String, _
    '                                                  ByVal PendingBillId As String, ByVal PendingBillAmmount As String, _
    '                                                  ByVal PendingBillCurrency As String, _
    '                                                  ByRef ErrorCode As String, ByRef ErrorDescription As String) As String

    '    'Dim lClsGbageM As New CapaNegocios.clsGbageM

    '    Return ""
    'End Function

    'Public Function ValidateInputs(ByVal variable As String, ByVal Campo As String, ByVal tipo As Integer) As Boolean
    '    Dim resp As Boolean = True

    '    Select Case tipo
    '        Case 0 ' Integer
    '            Try
    '                Convert.ToInt32(variable)
    '            Catch ex As Exception
    '                ErrorDescription = "Dato de Entrada NO v�lido. Valor NUMERICO, no permitido (" + Campo + "=" + variable + ")"
    '                resp = False
    '            End Try


    '        Case 1 ' Decimal
    '            Try
    '                Convert.ToDecimal(variable)
    '            Catch ex As Exception
    '                ErrorDescription = "Dato de Entrada NO v�lido. Valor DECIMAL, no permitido (" + Campo + "=" + variable + ")"
    '                resp = False
    '            End Try

    '    End Select
    '    Return resp

    'End Function

    'Public Sub SaveLogs(ByVal webService As String, ByVal input As String, ByVal output As String)

    '    Dim DTime As DateTime = DateTime.Now
    '    'logID es identity
    '    Dim instruction As String = "Insert into log (IP, UserID, date, webService, inputs, outputs) values (" _
    '                      + "IP" + "," + "UserID" + "," + DTime.ToString + "," + webService + "," + input + "," + output + ")"

    '    Dim vConnection As New SqlConnection("Data Source=skillsrv\sqlexpress;Initial Catalog=Skill3;Integrated Security=True")
    '    'vConnection.Open()
    '    'skillsrv\sqlexpress
    '    'Data Source=skillsrv\sqlexpress;Initial Catalog=Skill3;Integrated Security=True


    '    'Dim vCommand As New SqlCommand
    '    'vCommand.Connection = vConnection
    '    'vCommand.CommandText = instruction
    '    'vCommand.ExecuteNonQuery()

    '    'this.sqlConnectionPrueba.Open();
    '    '            this.sqlCommandPrueba.CommandText = "INSERT INTO  Cargo (CodCargo, Descripcion) values ("+cd+","+nombre+")";
    '    '           // this.sqlCommandPrueba.Parameters["cd"].Value = cd;
    '    '           // this.sqlCommandPrueba.Parameters["nombre"].Value = nombre;
    '    '            this.sqlCommandPrueba.ExecuteNonQuery();





    '    'Public Sub CreateSqlCommand(ByVal connection As SqlConnection, _
    '    'ByVal queryString As String, ByVal params() As SqlParameter)

    '    '    Dim command As New SqlCommand(queryString, connection)
    '    '    command.CommandText = _
    '    '       "SELECT CustomerID, CompanyName FROM Customers " _
    '    '       & "WHERE Country = @Country AND City = @City"
    '    '    command.UpdatedRowSource = UpdateRowSource.Both
    '    '    command.Parameters.Add(params)

    '    '    Dim j As Integer
    '    '    For j = 0 To command.Parameters.Count - 1
    '    '        command.Parameters.Add(params(j))
    '    '    Next j

    '    '    Dim message As String = ""
    '    '    Dim i As Integer
    '    '    For i = 0 To command.Parameters.Count - 1
    '    '        message += command.Parameters(i).ToString() & ControlChars.Cr
    '    '    Next i

    '    '    Console.WriteLine(message)
    '    'End Sub


    'End Sub


End Class
